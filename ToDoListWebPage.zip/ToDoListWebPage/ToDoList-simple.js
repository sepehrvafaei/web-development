let tasker = {
    construct: function () {
        this.selectElements();
        this.bindEvents();
        this.scanTaskList();
    },
    selectElements: function () {
        this.taskInput = document.getElementById("input-task");
        this.taskList = document.getElementById("tasks");
        this.taskListChildren = this.taskList.children;
        this.errorMessage = document.getElementById("error");
        this.addButton = document.getElementById("add-task-btn");
    },
    buildTask: function() {
        let taskListItem = document.createElement("li");
        let taskCheckBox = document.createElement("input");
        let taskValue = document.createTextNode("");
        let taskButton = document.createElement("button");
        let taskTrash = document.createElement("i");
        taskListItem.setAttribute("class", "task");
        taskCheckBox.setAttribute("type", "ckeckbox");
        taskTrash.setAttribute("class", "fa fa-trash");
        taskButton.appendChild(taskTrash);
        taskListItem.appendChild(taskCheckBox);
        taskListItem.appendChild(taskButton);
        taskListItem.appendChild(taskValue);
        this.taskList.appendChild(taskListItem);
    },
    error: () => {
        this.errorMessage.style.display = "block";
    },
    addTask: function(){
        let taskValue = this.taskInput.value;
        this.errorMessage.display = "none";
        if (textValue === "") {
            this.error();
        } else {
            this.buildTask();
            this.taskInput.value = "";
            this.scanTaskList();
        }
    },
    enterKey: function(event)  {
        if (event.KeyCode===13 || event.wich===13) {
            this.addTask();
        }
    },
    bindEvents: () => {
        this.addButton.onclick = this.addTask.bind(this);
        this.taskInput.onKeypress = this.enterKey.bind(this);
    },
    scanTaskList: () => {
        let tasListItem, checkbox, trash;
        for (let i = 0; i < this.taskListChildren.length; i++) {
            tasListItem = this.taskListChildren[i];
            checkbox =taskListItem.getElementByTagName("input")[0];
            trash = taskListItem.getElementByTagName("button")[0];
            checkbox.onclick = this.completeTask.bind(this, taskListItem, ckeckbox);
            trash.onclick = this.deleteTask.bind(this, i);
        }
    },
    deleteTask: (i) => {
        this.taskListChildren[i].remove();
        this.scanTaskList();
    },
    completetask: (taskListItem, ckeckbox) => {
        if (ckeckbox.checked) { taskListItem.className = "task-done"; }
        else { this.incompleteTask(taskListItem); }
    },
    incompleteTask: (taskListItem) => {
        taskListItem.className = "task";
    }
};
