let tasker = {
    construct: function () {
        this.selectElements();
        this.bindEvents();
        this.scanTaskList();
        this.showDate();
        this.currentTime();
    },
    showDate: function () {
        const monthNames = ["January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"];
        var weekdays = new Array(7);
        weekdays[0] = "Sunday";
        weekdays[1] = "Monday";
        weekdays[2] = "Tuesday";
        weekdays[3] = "Wednesday";
        weekdays[4] = "Thursday";
        weekdays[5] = "Friday";
        weekdays[6] = "Saturday";
        var date = new Date();
        var month = monthNames[date.getMonth()];
        var dayNum = date.getDate();
        var day = weekdays[date.getDay()];
        document.getElementById("date").innerHTML = month + ' ' + dayNum + ' ' + day;
    },
    currentTime:function() {
        var date = new Date();
        var hour = date.getHours();
        var min = date.getMinutes();
        var sec = date.getSeconds();
        hour = this.updateTime(hour);
        min = this.updateTime(min);
        sec = this.updateTime(sec);
        document.getElementById("time").innerHTML = hour + " : " + min + " : " + sec;
        setTimeout(this.currentTime.bind(this), 1000);
    },
    updateTime:function (k) {
        if (k < 10) {
            return "0" + k;
        }
        else {
                return k;
            }
    },
    selectElements: function () {
        this.taskInput = document.getElementById("input-task");
        this.taskList = document.getElementById("tasks");
        this.taskListChildren = this.taskList.children;
        this.errorMessage = document.getElementsByClassName("error")[0];
        this.addButton = document.getElementById("add-task-btn");
    },
    buildTask: function(val) {
        let taskListItem = document.createElement("li");
        let taskCheckBox = document.createElement("input");
        let taskValue = document.createTextNode(val);
        let taskButton = document.createElement("button");
        let taskTrash = document.createElement("i");
        taskListItem.setAttribute("class", "task");
        taskCheckBox.setAttribute("type", "checkbox");
        taskTrash.setAttribute("class", "fa fa-fw fa-trash-o");
        taskButton.appendChild(taskTrash);
        taskListItem.appendChild(taskCheckBox);
        taskListItem.appendChild(taskValue);
        taskListItem.appendChild(taskButton);
        this.taskList.appendChild(taskListItem);
        document.get
    },
    error: function(){
        this.errorMessage.style.display = "block";
    },
    addTask: function(){
        let taskValue = this.taskInput.value;
        this.errorMessage.style.display = "none";
        if (taskValue === "") {
            this.error();
        } else {
            this.buildTask(taskValue);
            this.taskInput.value = "";
            this.scanTaskList();
        }
    },
    bindEvents: function(){
        this.addButton.onclick = this.addTask.bind(this);
        this.taskInput.addEventListener('onKeypress', function (event) {
            if (event.KeyCode === 13 || event.which === 13) {
                this.addTask();
            };
        });
    },
    scanTaskList: function (){
        let taskListItem, checkbox, trash;
        for (let i = 0; i < this.taskListChildren.length; i++) {
            taskListItem = this.taskListChildren[i];
            checkbox = taskListItem.getElementsByTagName('input')[0];
            trash = taskListItem.getElementsByTagName('button')[0];
            checkbox.onclick = this.completeTask.bind(this, taskListItem, checkbox);
            trash.onclick = this.deleteTask.bind(this, i);
        }
    },
    deleteTask: function (i){
        this.taskListChildren[i].remove();
        this.scanTaskList();
    },
    completeTask: function (taskListItem, checkbox) {
        if (checkbox.checked) {
            //taskListItem.classList.remove('task');
            taskListItem.classList.add('task-done');
        }
        else { this.incompleteTask(taskListItem); }
    },
    incompleteTask:function (taskListItem) {
        taskListItem.className = "task";
    }
};
