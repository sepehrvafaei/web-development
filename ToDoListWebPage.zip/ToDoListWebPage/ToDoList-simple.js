var db = openDatabase('mydb', '1.0', 'Schedule', 2 * 1024 * 1024);
db.transaction(function (tx) {
    tx.executeSql('CREATE TABLE IF NOT EXISTS Schedule (Date DATE,Task TEXT,Time TIME,CONSTRAINT PK_DT PRIMARY KEY (Date,Time))');
});
let tasker = {
    construct: function () {
        this.selectElements();
        this.bindEvents();
        this.scanTaskList();
        this.showDate();
        this.currentTime();
    },
    showDate: function () {
        const monthNames = ["January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"];
        var weekdays = new Array(7);
        weekdays[0] = "Sunday";
        weekdays[1] = "Monday";
        weekdays[2] = "Tuesday";
        weekdays[3] = "Wednesday";
        weekdays[4] = "Thursday";
        weekdays[5] = "Friday";
        weekdays[6] = "Saturday";
        var date = new Date();
        var month = monthNames[date.getMonth()];
        var dayNum = date.getDate();
        var day = weekdays[date.getDay()];
        document.getElementById("date").innerHTML = month + ' ' + dayNum + ' ' + day;
    },
    currentTime: function () {
        var date = new Date();
        var hour = date.getHours();
        var min = date.getMinutes();
        var sec = date.getSeconds();
        hour = this.updateTime(hour);
        min = this.updateTime(min);
        sec = this.updateTime(sec);
        document.getElementById("time").innerHTML = hour + " : " + min + " : " + sec;
        setTimeout(this.currentTime.bind(this), 1000);
    },
    updateTime: function (k) {
        if (k < 10) {
            return "0" + k;
        }
        else {
            return k;
        }
    },
    selectElements: function () {
        this.taskTime = document.getElementById("task-time");
        this.taskInput = document.getElementById("input-task");
        this.taskList = document.getElementById("tasks");
        this.taskListChildren = this.taskList.children;
        this.errorMessage = document.getElementsByClassName("error")[0];
        this.addButton = document.getElementById("add-task-btn");
    },
    buildTask: function (val) {
        let taskListItem = document.createElement("li");
        let taskCheckBox = document.createElement("input");
        let taskValue = document.createTextNode(val);
        let taskButton = document.createElement("button");
        let taskTrash = document.createElement("i");
        taskListItem.setAttribute("class", "task");
        taskCheckBox.setAttribute("type", "checkbox");
        taskTrash.setAttribute("class", "fa fa-fw fa-trash-o");
        taskButton.appendChild(taskTrash);
        taskListItem.appendChild(taskCheckBox);
        taskListItem.appendChild(taskValue);
        taskListItem.appendChild(taskButton);
        this.taskList.appendChild(taskListItem);
        document.get
    },
    error: function () {
        this.errorMessage.style.display = "block";
    },
    addTask: function () {
        let taskValue = this.taskInput.value;
        this.errorMessage.style.display = "none";
        if (taskValue === "") {
            this.error();
        } else {
            let taskDateTime = this.taskTime.value.split("T");
            let taskDate = taskDateTime[0];
            let taskTime = taskDateTime[1];
            db.transaction(function (tx) {
                tx.executeSql('INSERT INTO Schedule (Date, Task,Time) VALUES (?, ?,?)', [taskDate, taskValue, taskTime]);
            });
            this.buildTask(taskValue);
            this.taskInput.value = "";
            this.scanTaskList();
        }
    },
    bindEvents: function () {
        this.addButton.onclick = this.addTask.bind(this);
        this.taskInput.addEventListener('onKeypress', function (event) {
            if (event.KeyCode === 13 || event.which === 13) {
                this.addTask();
            };
        });
    },
    scanTaskList: function () {
        let taskListItem, checkbox, trash;
        for (let i = 0; i < this.taskListChildren.length; i++) {
            taskListItem = this.taskListChildren[i];
            checkbox = taskListItem.getElementsByTagName('input')[0];
            trash = taskListItem.getElementsByTagName('button')[0];
            checkbox.onclick = this.completeTask.bind(this, taskListItem, checkbox);
            trash.onclick = this.deleteTask.bind(this, i);
        }
    },
    deleteTask: function (i) {
        this.taskListChildren[i].remove();
        this.scanTaskList();
    },
    completeTask: function (taskListItem, checkbox) {
        if (checkbox.checked) {
            //taskListItem.classList.remove('task');
            taskListItem.classList.add('task-done');
        }
        else { this.incompleteTask(taskListItem); }
    },
    incompleteTask: function (taskListItem) {
        taskListItem.className = "task";
    },
};
document.addEventListener("DOMContentLoaded", function () {

    var dropDownMenue = document.getElementsByClassName("dropdown-menue")[0];
    function findTasks() {
        db.transaction(function (tx) {
            tx.executeSql(`SELECT * FROM Schedule WHERE Date=${document.getElementById("task-date").value}`, [], function (tx, results) {
                var len = results.rows.length, i;
                for (i = 0; i < len; i++) {
                    document.getElementsByClassName("dropdown-menue")[0].insertAdjacentHTML('beforeend', `<p class="dropdown-item">${results.rows.item(i).Task}</p>`);
                }
            });
        });
    }
    document.getElementById("enter_date").onclick = findTasks;

    //weather
    let long;
    let lat;
    let tempDes = document.getElementsByClassName("tempDes");
    let tempDeg = document.getElementsByClassName("tempDeg");
    let timezone = document.getElementsByClassName("timezone");
    let observation = document.getElementsByClassName("observation");
    let counter = 0;
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            lon = position.coords.longitude;
            lat = position.coords.latitude;
            const proxy = "https://cors-anywhere.herokuapp.com/";
            fetch(`${proxy}https://climacell-microweather-v1.p.rapidapi.com/weather/nowcast?fields=temp,weather_code&unit_system=si&lat=${lat}&lon=${lon}`, {
                "method": "GET",
                "headers": {
                    "x-rapidapi-host": "climacell-microweather-v1.p.rapidapi.com",
                    "x-rapidapi-key": "d2d765aceemshea3c9ca608c26fep1d9c41jsn2418072501d1",
                    "origin": "http://localhost/D:/webDevelopment/ToDoListWebPage/ToDoList-simple.html"
                }
            }).then(response => {
                    return response.json();
                }).then(data => {
                    for (let i = 0; i <73;i+=18) {
                        observation[counter].innerHTML = data[i].observation_time.value.split("T")[0] + "/" +
                            data[i].observation_time.value.split("T")[1].slice(0, 5);
                        tempDeg[counter].innerHTML = data[i].temp.value +"&#8451;";
                        tempDes[counter].innerHTML = data[i].weather_code.value;
                        document.getElementsByClassName("icon")[counter].src = "black/" + data[i].weather_code.value + ".svg";
                        counter += 1;
                    }
                }).catch(err => {
                    console.log(err);
                });
        });
    } else {
        alert("position not working");
    }
    
});