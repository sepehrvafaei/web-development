const members = [
    {
        id: 1,
        name: 'Jone Doe',
        email: 'john@gmail.com',
        status: 'active'
    },
    {
        id: 2,
        name: 'Joey Trib',
        email: 'Joey@gmail.com',
        status: 'inactive'
    }
];
module.exports = members;